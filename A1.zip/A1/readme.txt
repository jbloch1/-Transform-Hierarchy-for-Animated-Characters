Name: Jonathan Bernard Bloch
Student ID: 260632216

I created a robot named Dave. He has only a head, a torso and 2 hands composed of two parts. There is an animation and a movie of him flapping his hands to Mr Roboto.

I used the rnd button to do keyframe animation and constrained the motion by giving more arguments to the joint nodes. This gives Dave a spastic look. New classes were created from DAGNode for goemetry: Arm, Box, and Sphere. FreeJoint was used for the root so he could walk around. HingeJoint was the most common. I fixed the translations and just the rotation fluctuates. This is realistic for joints. BallJoint was used to mirror the arms. Dave is a robot and he is monochromatic. 

